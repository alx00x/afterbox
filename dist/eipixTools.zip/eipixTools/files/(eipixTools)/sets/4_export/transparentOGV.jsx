﻿// transparentOGV.jsx
// 
// Name: transparentOGV
// Version: 2.3
// Author: Aleksandar Kocic
// 
// Description:     
// This script prepares a composition and adds render items
// for engine use. Script checks if dimensions are dividable 
// by 16 and offers an option to reduce unnecessarily space 
// around the object.
// 

(function transparentOGV(thisObj) {
    if (app.project.file == null) {
        alert("Save the project first.");
        return;
    }

    if (app.project.activeItem == null) {
        alert("Please, select your composition.");
        return;
    }

    // Define main variables
    var togvData = new Object();

    togvData.scriptNameShort = "TOGV";
    togvData.scriptName = "Transparent OGV";
    togvData.scriptVersion = "2.3";
    togvData.scriptTitle = togvData.scriptName + " v" + togvData.scriptVersion;

    togvData.strMinAE = {en: "This script requires Adobe After Effects CS4 or later."};
    togvData.strActiveCompErr = {en: "Please select a composition."};
    togvData.strNoSelectErr = {en: "Select at least one background layer."};

    togvData.strExecute = {en: "Execute"};
    togvData.strCancel = {en: "Cancel"};

    togvData.strExportTo = {en: "Export To"};
    togvData.strBrowse = {en: "Browse"};
    togvData.strBrowseText = {en: "Save OGV and PNG to:"};

    togvData.strOptions = {en: "Options"};

    togvData.strWarning = {en: "Warning: Enabling this options for big and lengthy compositions could significantly increase the execution time. Setting smaller than 5 sample size is not recommended"};
    togvData.strPNGWarning = {en: "Warning: Could not find \"" + togvData.outputTemplateName + "\" output template. It is highly recommended to either make a template by that name or import it by pressing [IMP REND] button under eipixTools panel. Exporting as PSD for now."};
    togvData.strSpreadsheetErr = {en: "You need to specify output first."};
    togvData.strOutputErr = {en: "Output is not valid."};

    togvData.strCrop = {en: "Crop to Edges"};
    togvData.strSamples = {en: "Samples"};
    togvData.strFrameSkip = {en: "Skip frames"};
    togvData.strFrameSkipOpts = [0, 1, 2, 5];

    togvData.strSamplesHelpTip = {en: "Lower the value, slower the execution."};
    togvData.strFrameSkipHelpTip = {en: "Lower the value, slower the execution."};

    togvData.strHelp = {en: "?"};
    togvData.strHelpTitle = {en: "Help"};
    togvData.strErr = {en: "Something went wrong."};
    togvData.strHelpText = {en: "This script prepares a composition and adds render items for engine use. Script checks if dimensions are dividable by 16 and offers an option to reduce unnecessarily space around the object."};

    // Define project variables
    togvData.outputQuality = "Best Settings";
    togvData.outputTemplateVid = "Lossless";
    togvData.outputTemplateImg = "PNG Sequence";
    togvData.activeItem = app.project.activeItem;
    togvData.activeItemFrames = app.project.activeItem.duration * app.project.activeItem.frameRate;
    togvData.projectFolder = app.project.file.parent;
    togvData.outputPath;

    // Localize
    function transparentOGV_localize(strVar) {
        return strVar["en"];
    }

    // Build UI
    function transparentOGV_buildUI(thisObj) {
        var pal = new Window("palette", togvData.scriptName, undefined, {resizeable:true});
        if (pal !== null) {
            var res =
                "group { \
                    orientation:'column', alignment:['fill','fill'], \
                    header: Group { \
                        alignment:['fill','top'], \
                        title: StaticText { text:'" + togvData.scriptNameShort + " v" + togvData.scriptVersion + "', alignment:['fill','center'] }, \
                        help: Button { text:'" + transparentOGV_localize(togvData.strHelp) + "', maximumSize:[30,20], alignment:['right','center'] }, \
                    }, \
                    options: Panel { \
                        alignment:['fill','top'], \
                        text: '" + transparentOGV_localize(togvData.strOptions) + "', alignment:['fill','top'], \
                        crp: Group { \
                            alignment:['left','center'], \
                            text: StaticText { text:'0 / 0', characters: 7, justify: 'center', alignment:['left','center'], preferredSize:[-1,20] }, \
                            loader: Progressbar { text:'Progressbar', minvalue:0, maxvalue:100, preferredSize:[260,5]},\
                            box1: Checkbox { text:'" + transparentOGV_localize(togvData.strCrop) + "' }, \
                        }, \
                        skp: Group { \
                            alignment:['fill','top'], \
                            text: StaticText { text:'" + transparentOGV_localize(togvData.strFrameSkip) + ":', preferredSize:[120,20] }, \
                            list: DropDownList { alignment:['fill','center'], preferredSize:[120,20] }, \
                        }, \
                        sam: Group { \
                            alignment:['fill','top'], \
                            text: StaticText { text:'" + transparentOGV_localize(togvData.strSamples) + ":', preferredSize:[120,20] }, \
                            fld: EditText { text:'5', characters: 3, justify: 'center', alignment:['left','center'], preferredSize:[-1,20] }, \
                            sld: Slider { value:5, minvalue:1, maxvalue:20, alignment:['fill','center'], preferredSize:[200,20] }, \
                        }, \
                    }, \
                    output: Panel { \
                        alignment:['fill','top'], \
                        text: '" + transparentOGV_localize(togvData.strExportTo) + "', alignment:['fill','top'], \
                        select: Group { \
                            alignment:['fill','top'], \
                            fld: EditText { alignment:['fill','center'], preferredSize:[250,20] },  \
                            btn: Button { text:'" + transparentOGV_localize(togvData.strBrowse) + "', preferredSize:[-1,20] }, \
                        }, \
                    }, \
                    sepr: Group { \
                        orientation:'row', alignment:['fill','top'], \
                        rule: Panel { height: 2, alignment:['fill','center'] }, \
                    }, \
                    cmds: Group { \
                        alignment:['fill','top'], \
                        executeBtn: Button { text:'" + transparentOGV_localize(togvData.strExecute) + "', alignment:['center','bottom'], preferredSize:[-1,20] }, \
                        cancelBtn: Button { text:'" + transparentOGV_localize(togvData.strCancel) + "', alignment:['center','bottom'], preferredSize:[-1,20] }, \
                    }, \
                }, \
            }";
            pal.grp = pal.add(res);

            pal.layout.layout(true);
            pal.grp.minimumSize = pal.grp.size;
            pal.layout.resize();
            pal.onResizing = pal.onResize = function() {
                this.layout.resize();
            }

            pal.grp.output.select.btn.onClick = function() {
                transparentOGV_doBrowse();
            }

            pal.grp.options.crp.box1.helpTip = transparentOGV_localize(togvData.strWarning);
            pal.grp.options.skp.list.helpTip = transparentOGV_localize(togvData.strFrameSkipHelpTip);
            pal.grp.options.sam.sld.helpTip = transparentOGV_localize(togvData.strSamplesHelpTip);

            //Skip dropdown menu
            var skipItems = togvData.strFrameSkipOpts;
            for (var i = 0; i < skipItems.length; i++) {
                pal.grp.options.skp.list.add("item", skipItems[i]);
            }
            pal.grp.options.skp.list.selection = 0;

            //Samples slider change
            pal.grp.options.sam.fld.onChange = function() {
                var value = parseInt(this.text);
                if (isNaN(value)) {
                    value = this.parent.sld.value;
                } else if (value < this.parent.sld.minvalue) {
                    value = this.parent.sld.minvalue;
                } else if (value > this.parent.sld.maxvalue) {
                    value = this.parent.sld.maxvalue;
                }
                this.text = value.toString();
                this.parent.sld.value = value;
            }
            pal.grp.options.sam.sld.onChange = pal.grp.options.sam.sld.onChanging = function() {
                var value = parseInt(this.value);
                if (isNaN(value)) {
                    value = parseInt(this.parent.fld.text);
                }
                this.value = value;
                this.parent.fld.text = value.toString();
            }

            pal.grp.options.skp.text.enabled = false;
            pal.grp.options.skp.list.enabled = false;
            pal.grp.options.crp.box1.value = false;
            pal.grp.options.crp.text.visible = false;
            pal.grp.options.crp.text.enabled = false;
            pal.grp.options.crp.loader.visible = false;
            pal.grp.options.sam.text.enabled = false;
            pal.grp.options.sam.fld.enabled = false;
            pal.grp.options.sam.sld.enabled = false;
            //var warningShow = true;

            pal.grp.options.crp.box1.onClick = function() {
                if (pal.grp.options.crp.box1.value == true) {
                    pal.grp.options.skp.text.enabled = true;
                    pal.grp.options.skp.list.enabled = true;
                    pal.grp.options.sam.text.enabled = true;
                    pal.grp.options.sam.fld.enabled = true;
                    pal.grp.options.sam.sld.enabled = true;
                    pal.grp.options.crp.text.visible = true;
                    pal.grp.options.crp.loader.visible = true;
                    //if (warningShow == true) {
                    //    alert(transparentOGV_localize(togvData.strWarning));
                    //    warningShow = false;
                    //}
                } else {
                    pal.grp.options.skp.text.enabled = false;
                    pal.grp.options.skp.list.enabled = false;
                    pal.grp.options.sam.text.enabled = false;
                    pal.grp.options.sam.fld.enabled = false;
                    pal.grp.options.sam.sld.enabled = false;
                    pal.grp.options.crp.text.visible = false;
                    pal.grp.options.crp.loader.visible = false;
                }
            }

            pal.grp.header.help.onClick = function() {
                alert(togvData.scriptTitle + "\n" + transparentOGV_localize(togvData.strHelpText), transparentOGV_localize(togvData.strHelpTitle));
            }

            pal.grp.cmds.executeBtn.onClick = transparentOGV_doExecute;
            pal.grp.cmds.cancelBtn.onClick = transparentOGV_doCancel;
        }

        return pal;
    }

    // Progressbar function:
    //
    function updateProgressbar(pal, minValue, currentValue, maxValue) {
        pal.grp.options.crp.loader.minvalue = minValue;
        pal.grp.options.crp.loader.maxvalue = maxValue;
        pal.grp.options.crp.loader.value = currentValue;
        pal.update();
    }

    // Progresstext function:
    //
    function updateProgresstext(pal, text) {
        pal.grp.options.crp.text.text = text;
        pal.update();
    }

    // Main Functions:
    //

    // Calculate first divisible by 16
    function transparentOGV_factorisation16(inputValue) {
        var valueDiv = 16;
        while (inputValue % valueDiv != 0) {
            inputValue += 1;
        }
        var value = inputValue;
        return value;
    }

    // Browse for location
    function transparentOGV_doBrowse() {
        var outputFile = togvData.projectFolder.selectDlg(transparentOGV_localize(togvData.strBrowseText));
        if (outputFile != null) {
            togvPal.grp.output.select.fld.text = outputFile.fsName.toString();
        }
    }

    // Detect edges for cropping
    function transparentOGV_edgeDetect(comp, samples, skip) {

        //create duplicate comp
        var analizeComp = comp.duplicate();
        analizeComp.name = "analizeComp_(" + comp.name + ")";
        var analizeFrames = analizeComp.layers.precompose([1], "analizeFrames_(" + comp.name + ")", true);
        var target = analizeComp.layers[1].name

        //duplicate layer and distribute frames to single frame
        var compFrames = Math.round(analizeFrames.duration * analizeFrames.frameRate);

        for (i = 0; i < compFrames; i += skip) {
            var firstLayer = analizeFrames.layers[1];
            var newLayer = firstLayer.duplicate()
            var newLayerStartTime = newLayer.startTime;
            newLayer.startTime = newLayerStartTime - (analizeFrames.frameDuration * skip);
        }

        //add null
        var addNull = analizeComp.layers.addNull();

        //add slider property to null
        var addSlider = addNull.Effects.addProperty("ADBE Slider Control");

        //analize for x1, x2, y1 and y2
        var compHeight = analizeComp.height;
        var compWidth = analizeComp.width;
 
        var x1 = compWidth; //left
        var x2 = -1; //right
        var y1 = compHeight; //top
        var y2 = -1; //bottom

        for (b = 0; b < compHeight; b += samples) {
            for (a = 0; a < compWidth; a += samples) {
                var expr = "thisComp.layer('" + target + "').sampleImage([" + a + "," + b + "], [" + samples + "," + samples + "]/2, true, 0)[3]";
                addSlider.property(1).expressionEnabled = true;
                addSlider.property(1).expression = expr;
                var value = addSlider(1).value;
                //find left edge
                if ((value > 0) && (a < x1)) {x1 = a;}
                //find right edge
                if ((value > 0) && (x2 < a)) {x2 = a;}
                //find top edge
                if ((value > 0) && (b < y1)) {y1 = b;}
                //find bottom edge
                if ((value > 0) && (y2 < b)) {y2 = b;}
            }
            updateProgresstext(togvPal, b + " / " + compHeight);
            updateProgressbar(togvPal, 0, b+1, compHeight);
        }

        analizeComp.remove();
        analizeFrames.remove();

        var arr = [Math.round(x1 - (samples / 2)), Math.round(x2 + (samples / 2)), Math.round(y1 - (samples / 2)), Math.round(y2 + (samples / 2))];
        return arr;
    }

    // Check Template
    function checkTemplate(templateName) {
        var renderQ = app.project.renderQueue;
        var tempComp = app.project.items.addComp("setProxyTempComp", 100, 100, 1, 1, 25);
        var tempCompQueueItem = renderQ.items.add(tempComp)
        var tempCompQueueItemIndex = renderQ.numItems;
        var templateArray = renderQ.item(tempCompQueueItemIndex).outputModules[1].templates;
        for (var i = 1; i <= renderQ.numItems; i++) {
            var templateExists = false;
            for (var j = 0; j <= templateArray.length; j++) {
                if (templateArray[j] == templateName) {
                    templateExists = true;
                }
            }
        }
        tempCompQueueItem.remove();
        tempComp.remove();

        return templateExists;
    }

    // main
    function transparentOGV_main() {      
        //get general info
        var outPath = togvData.outputPath;
        var frames = togvData.activeItemFrames;

        //get active comp info
        var activeComp = togvData.activeItem;
        var activeWidth = togvData.activeItem.width;
        var activeHeight = togvData.activeItem.height;
        var activeCompName = activeComp.name;
        var activeDuration = togvData.activeItem.duration;
        var activeFramerate = togvData.activeItem.frameRate;
        var activeFrameDuration = togvData.activeItem.frameDuration;
        var selectedLayers = [];
        var selectedLayersIndices = [];

        //create main folder
        var mainFolderItem = app.project.items.addFolder(activeCompName + "_OGV");

        selectedLayers = activeComp.selectedLayers;
        //get each selected layer's index
        for (var i = 0; i < selectedLayers.length; i++) {
            selectedLayersIndices.push(selectedLayers[i].index);
        }

        //copy source of activeComp
        var activeCompAlpha = activeComp.duplicate();
        activeCompAlpha.name = "alpha(" + activeCompName + ")";
        activeCompAlpha.parentFolder = mainFolderItem;

        //set selected layers as guides in copy of mainComp
        for (var i = 0; i < selectedLayersIndices.length; i++) {
            activeCompAlpha.layer(selectedLayersIndices[i]).guideLayer = true;
        }

        //create container for activeComp
        var mainCompName = "main_" + activeCompName;
        var mainCompWidth = activeWidth;
        var mainCompHeight = activeHeight;
        var mainCompFramerate = activeFramerate;
        var mainCompDuration = activeDuration;
        var mainComp = mainFolderItem.items.addComp(mainCompName, mainCompWidth, mainCompHeight, 1, mainCompDuration, mainCompFramerate);
        mainComp.layers.add(activeComp);

        //create container for activeCompAlpha
        var mainCompAlphaName = "alpha_" + activeCompName;
        var mainCompAlphaWidth = activeWidth;
        var mainCompAlphaHeight = activeHeight;
        var mainCompAlphaFramerate = activeFramerate;
        var mainCompAlphaDuration = activeDuration;
        var mainCompAlpha = mainFolderItem.items.addComp(mainCompAlphaName, mainCompAlphaWidth, mainCompAlphaHeight, 1, mainCompAlphaDuration, mainCompAlphaFramerate);
        mainCompAlpha.layers.add(activeCompAlpha);

        //crop mainComp and mainCompAlpha to edges if requested
        if (togvPal.grp.options.crp.box1.value == true) {
            //detect edges
            var numOfSamples = parseInt(togvPal.grp.options.sam.fld.text);
            var skipValue = parseInt(String(togvPal.grp.options.skp.list.selection)) + 1;
            var targetEdges = transparentOGV_edgeDetect(mainCompAlpha, numOfSamples, skipValue);

            //offset mainComp layer to accommodate new dimensions
            var layerPos = mainComp.layers[1].property("Transform").property("Position").value;
            mainComp.layers[1].property("Transform").property("Position").setValue([layerPos[0] - targetEdges[0], layerPos[1] - targetEdges[2]]);

            //offset mainCompAlpha layer to accommodate new dimensions
            var layerPos = mainCompAlpha.layers[1].property("Transform").property("Position").value;
            mainCompAlpha.layers[1].property("Transform").property("Position").setValue([layerPos[0] - targetEdges[0], layerPos[1] - targetEdges[2]]);

            //crop comp to edges
            var newWidth = mainCompWidth - (targetEdges[0] + (mainCompWidth - targetEdges[1]));
            var newHeight = mainCompHeight - (targetEdges[2] + (mainCompHeight - targetEdges[3]));

            //crop mainComp
            mainComp.width = transparentOGV_factorisation16(newWidth);
            mainComp.height = transparentOGV_factorisation16(newHeight);

            //crop mainCompAlpha
            mainCompAlpha.width = transparentOGV_factorisation16(newWidth);
            mainCompAlpha.height = transparentOGV_factorisation16(newHeight);
        } else {
            //crop mainComp
            mainComp.width = transparentOGV_factorisation16(mainComp.width);
            mainComp.height = transparentOGV_factorisation16(mainComp.height);

            //crop mainCompAlpha
            mainCompAlpha.width = transparentOGV_factorisation16(mainComp.width);
            mainCompAlpha.height = transparentOGV_factorisation16(mainComp.height);
        }

        //setup the export
        try {
            var endFrame = mainComp.duration - mainComp.frameDuration;
            var oneFrame = mainComp.frameDuration;
            var newCompName = "ogv(" + mainComp.name + ")";
            var newCompWidth = mainComp.width * 2;
            var offsetLeft = mainComp.width / 2;
            var offsetRight = (mainComp.width / 2) * 3;
            var offsetHight = mainComp.height / 2;
            var newComp = mainFolderItem.items.addComp(newCompName, newCompWidth, mainComp.height, mainComp.pixelAspect, mainComp.duration, mainComp.frameRate);
            newComp.layers.add(mainComp);
            newComp.layers.add(mainCompAlpha);
            var L1 = newComp.layers[2];
            var L2 = newComp.layers[1];
            L1.property("ADBE Transform Group").property("ADBE Position").setValue([offsetLeft,offsetHight]);
            L2.property("ADBE Transform Group").property("ADBE Position").setValue([offsetRight,offsetHight]);
            L2.property("Effects").addProperty("Fill").property("Color").setValue([1,1,1,1]);
            var newCompBG = newComp.layers.addSolid([0,0,0], "compBG", newComp.width, newComp.height, newComp.pixelAspect, newComp.duration);
            newCompBG.moveToEnd();
            //add avi to render queue
            var renderQueueComp = app.project.renderQueue.items.add(newComp);
            var renderQueueCompIndex = app.project.renderQueue.numItems;
            renderQueueComp.applyTemplate(togvData.outputQuality);
            renderQueueComp.timeSpanStart = 0;
            renderQueueComp.timeSpanDuration = newComp.duration;
            renderQueueComp.outputModules[1].applyTemplate(togvData.outputTemplateVid);
            renderQueueComp.outputModules[1].file = new File(togvData.outputPath.fsName.toString() + "\\" + activeCompName + "_a.avi");
            //add png to render queue
            var renderQueueThumb = app.project.renderQueue.items.add(mainComp);
            var renderQueueThumbIndex = app.project.renderQueue.numItems;
            renderQueueThumb.applyTemplate(togvData.outputQuality);
            renderQueueThumb.timeSpanStart = endFrame;
            renderQueueThumb.timeSpanDuration = oneFrame;
            renderQueueThumb.outputModules[1].applyTemplate(togvData.outputTemplateImg);
            renderQueueThumb.outputModules[1].file = new File(togvData.outputPath.fsName.toString() + "\\" + activeCompName + "_[#####].png");
            //render
            app.project.renderQueue.render();
        } catch (err) {
            alert(err.toString());
        }

        mainComp.openInViewer()

    }

    // Button Functions:
    //

    // Execute
    function transparentOGV_doExecute() {
        var outputPath = togvPal.grp.output.select.fld.text;
        if (outputPath != "") {
            togvData.outputPath = new File(outputPath);
            if (togvData.outputPath.exists == true) {
                if (togvData.activeItem.selectedLayers.length === 0) {
                    alert(transparentOGV_localize(togvData.strNoSelectErr));
                } else {
                    app.beginUndoGroup(togvData.scriptName);
                    var checkPoint = checkTemplate(togvData.outputTemplateName);
                    if (checkPoint == false) {
                        alert(transparentOGV_localize(togvData.strPNGWarning));
                    }
                    transparentOGV_main();
                    app.endUndoGroup();
                    togvPal.close();    
                }
            } else {
                alert(transparentOGV_localize(togvData.strOutputErr));
            }
        } else {
            alert(transparentOGV_localize(togvData.strSpreadsheetErr));
        }
    }

    // Cancel
    function transparentOGV_doCancel() {
        togvPal.close();
    }

    // Main code:
    //

    // Warning
    if (parseFloat(app.version) < 9.0) {
        alert(transparentOGV_localize(togvData.strMinAE));
    } else {
        // Build and show the floating palette
        var togvPal = transparentOGV_buildUI(thisObj);
        if (togvPal !== null) {
            if (togvPal instanceof Window) {
                // Show the palette
                togvPal.center();
                togvPal.show();
            } else {
                togvPal.layout.layout(true);
            }
        }
    }
})(this);