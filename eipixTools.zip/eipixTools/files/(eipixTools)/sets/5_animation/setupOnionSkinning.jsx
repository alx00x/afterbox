// setupOnionSkinning.jsx
// 
// Name: setupOnionSkinning
// Version: 0.1
// Author: Aleksandar Kocic
// 
// Description: 
// 
// 

(function setupOnionSkinning(thisObj) {
    alert("Work in Progress");
})(this);